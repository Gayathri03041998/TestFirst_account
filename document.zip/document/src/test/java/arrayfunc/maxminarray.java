package arrayfunc;

public class maxminarray {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		max();
	}
	public static void max() {
		int[] a= {100,1000,30,90,50};
		int max=a[1];
		int min=a[1];
		//we are starting from 1 bcz we considered 0 as max
		for(int i=0;i<a.length;i++) {
			if(max<a[i]) {
				max=a[i];
			}
			if(min>a[i]) {
				min=a[i];
			}
		}
		System.out.println("maximum value is "+max);
		System.out.println("minimum value is "+min);
	}
}
