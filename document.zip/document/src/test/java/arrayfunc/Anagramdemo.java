package arrayfunc;

import java.util.Arrays;

public class Anagramdemo {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ana();
	}
	//for anagram both string length should be same
	public static void ana() {
		String a1="MAPP";
		String a2="PPAM";
		char[] c1=a1.toCharArray();
		char[] c2=a2.toCharArray();
		if(a1.length()==a2.length()) {		
				
			Arrays.sort(c1);
			Arrays.sort(c2);
			if(Arrays.equals(c1, c2)) {
				System.out.println("anagram");
		}
			else {
				System.out.println("Not a anagram");
			}
			
}
	}}
