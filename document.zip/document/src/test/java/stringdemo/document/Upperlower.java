package stringdemo.document;

public class Upperlower {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
	

public static void capsmall() {
	String d2= "666SayDa";
	String count="";
	String hen="";
	
	for(int i=0;i<=d2.length()-1;i++) {
		//if(!(d2.charAt(i)>='a')&&(d2.charAt(i)<='z')||(d2.charAt(i)>='A')&& (d2.charAt(i)<='Z')){
		if (d2.charAt(i)>='a'&&d2.charAt(i)<='z'){
			count=count+d2.charAt(i);
		}
		else if((d2.charAt(i)>='A')&&(d2.charAt(i)<='Z')) {
					hen=hen+d2.charAt(i);
		}
	
		
}
	System.out.println(count.length());
	System.out.println(hen.length());
}
public static void work() {
String s1="gayathri1234Magesh@gmail.com";
//String S2=s1.substring(0, 1).toUpperCase();
//String s3=s1.substring(1, 3);
//String S4=s1.substring(12,13).toLowerCase();
//System.out.println(S2+s3+S4);
//String S5[]=s1.split("@");
//System.out.println(S5[0]);
char s=' ';
for(int i=0;i<=s1.length()-1;i++){

	s=s1.charAt(i);
		s=(char) (s-32);
	
}
System.out.println(s);
}
}




