package stringdemo.document;

public class Lengthwithoutlength {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		lengthm();
	}
public static void lengthm() {
	String s1="Love123";
	int count=0;
	for(int temp:s1.toCharArray()) {
		count++;
	}
	System.out.println(count);
}
}
