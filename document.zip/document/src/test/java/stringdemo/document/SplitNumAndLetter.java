package stringdemo.document;

public class SplitNumAndLetter {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		splitnum();
		splitletters();
		removespl();
	}
	
	//Split number and string
	public static void splitnum() {
		String d1="gayu273";
		String d2="";
		String d3="";
		for(int i=0;i<d1.length();i++) {
			if((d1.charAt(i)>='0')&&(d1.charAt(i)<='9')) {
			d2=d2+d1.charAt(i);
	}
			else{
				d3=d3+d1.charAt(i);
			}}
		int countnum=d2.length();
		int countstring=d3.length();
		
		System.out.println("numcount="+countnum+" "+"Stringcount="+countstring);
	}
	
	//remove special character
	public static void splitletters() {
	String d2="gayusandy3@gmail.com";
	String d3="";
	String d4="";
	for(int i=0;i<d2.length();i++) {
		if((d2.charAt(i)>='a' && d2.charAt(i)<='z')||(d2.charAt(i)>='A' && d2.charAt(i)<='Z')||(d2.charAt(i)>='0' && d2.charAt(i)<='9')) {
			d3=d3+d2.charAt(i);
		}
		else{
			d4=d4+d2.charAt(i);
		}
		}
System.out.println(d3);
System.out.println(d4);
}
	public static void numspl() {
	String d2="gaya273@thri";
	for(int i=0;i<=d2.length()-1;i++) {
		if(!(d2.charAt(i)>='a')&&(d2.charAt(i)<='z')||(d2.charAt(i)>='A')&&(d2.charAt(i)<='Z')) {
			System.out.print(d2.charAt(i));	
		}		
}
	}
	//remove special character
	public static void removespl() {
		String d2="gay@)..(a273@thri";
		String d3=d2.replaceAll("[^a-zA-Z0-9]","");
		//remove aphabets and num
		//String d3=d2.replaceAll("[^a-zA-Z0-9]","");
		System.out.print(d3);	
	}}