package stringdemo.document;

public class reverse {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		reversesentence();
	}
	public static void reverse() {
		String input="gayathri";
		String output="";
		for(int i=input.length()-1;i>=0;i--){ //here we are taking lenth-1 //9-1
			output=output+input.charAt(i);
		}
		System.out.println(output);}
	
	public static void reversesentence() {
		String input="Hi This is my program";
		String[] output=input.split(" ");
		String newone="";
		for(int i=output.length-1;i>=0;i--){ //here we are taking lenth-1 //9-1
			newone=newone+" "+output[i];
		}
		System.out.println(newone);}

}
