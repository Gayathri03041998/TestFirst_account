package stringdemo.document;

public class charcount {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		charcount();
	}
	public static void charcount() {
	String s1 = "payilagama";
	char s2 = 'a';
	int count=0;
	for(int i=0;i<s1.length();i++) {
		if(s2==s1.charAt(i)) {
			count++;				
	}
	}
	System.out.println(count);
	}
}
