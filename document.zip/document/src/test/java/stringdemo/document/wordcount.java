package stringdemo.document;

public class wordcount {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
	public static void wordcount() {
	String d="Hai welcome to the automation world hai";
	int count=1;
	for(int i=0;i<=d.length()-1;i++) {
		if((d.charAt(i)==' ')&&( d.charAt(i+1)!=' ')) {
			count++;
}}System.out.println(count);
}
}
