package stringdemo.document;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import io.github.bonigarcia.wdm.WebDriverManager;

public class XpathDemo {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		//WebDriver Manager in POM file will automatically download .exe file of chrome
		WebDriverManager.chromedriver().setup();
		
		//if we are using selenium version 4.6 above no need to write above manager line below line is enough
		WebDriver driver=new ChromeDriver();
		driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
		System.out.println(driver.getTitle());
		driver.manage().window().maximize();
		Thread.sleep(3000);
//1.Locating elemment with known attribute:		
WebElement username= driver.findElement(By.xpath("//*[@name='username']"));
username.sendKeys("Admin");
Thread.sleep(3000);

//2.Locate element with Known Element & Attribute:
WebElement password=driver.findElement(By.xpath("//input[@name='password']"));
password.sendKeys("admin123");
Thread.sleep(3000);

//3.Locating Element with known visible Text(Exact match)
WebElement forgot=driver.findElement(By.xpath("//*[text()='Forgot your password? ']"));
String ForText=forgot.getText();
System.out.println(ForText);

//4.Locating Elements when part of the visible text is known(partial match)
WebElement text=driver.findElement(By.xpath("//a[contains(text(),'Orange')]"));
String containTxt=text.getText();
System.out .println(containTxt);


//5.Locating elements with multiple Attributes
driver.findElement(By.xpath("//button[@type='submit'][@class='oxd-button oxd-button--medium oxd-button--main orangehrm-login-button']")).click();

//6.Locating Element when starting visible text is known
Thread.sleep(3000);
driver.findElement(By.xpath("//p[starts-with(text(),'Test')]")).click();


	}

}
